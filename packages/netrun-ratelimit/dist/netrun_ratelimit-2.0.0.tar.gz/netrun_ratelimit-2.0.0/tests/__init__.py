"""Tests for netrun-ratelimit."""
