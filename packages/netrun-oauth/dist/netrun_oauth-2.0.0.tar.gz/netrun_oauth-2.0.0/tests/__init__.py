"""
Tests for netrun-oauth package

Part of: netrun-oauth v1.0.0
"""
