"""Test suite for netrun-env package."""
