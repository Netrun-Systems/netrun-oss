"""Test suite for netrun-errors package."""
