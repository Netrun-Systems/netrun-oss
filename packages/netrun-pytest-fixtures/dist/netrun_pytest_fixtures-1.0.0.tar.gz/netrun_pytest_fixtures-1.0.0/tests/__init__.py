"""Tests for netrun-pytest-fixtures package."""
